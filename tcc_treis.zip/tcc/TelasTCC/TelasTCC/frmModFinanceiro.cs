﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Financeiro;
using TelasTCC.DB.Login;

namespace TelasTCC
{
    public partial class frmModFinanceiro : Form
    {
        public frmModFinanceiro()
        {
            InitializeComponent();
            ListarFolhaPagamento();
        }
        
        private void btnCaixa_Click(object sender, EventArgs e)
        {
            /*gbCaixa.Visible = true;
            gbCaixa.Enabled = true;
            cbDia.Checked = true;
            dataGridPagamento.Visible = false;*/
        }

        private void btnVendasCard_Click(object sender, EventArgs e)
        {
            lblCartao.Text = "Vendas em cartão: " + "56";
            lblRecCartao.Text = "Recebido em cartão: " + "R$ 387,90";
            lblDinheiro.Text = "Vendas em dinheiro: " + "12";
            lblRecDinheiro.Text = "Recebido em dinheiro" + "R$ 120,50";
            lblTotal.Text = "Valor total do " + "dia: " + "R$ 508,40";
        }
        private void ListarFolhaPagamento()
        {
            FinanceiroDTO dto = new FinanceiroDTO();

            FinanceiroBusiness business = new FinanceiroBusiness();
            List<FinanceiroDTO> lista = business.Listar();

            dgvPagamento.AutoGenerateColumns = false;
            dgvPagamento.DataSource = lista;
        }

        private void btnPeriodo_Click(object sender, EventArgs e)
        {
            if (radDia.Checked == true || radMes.Checked == true || radAno.Checked == true)
            {
                FinanceiroDatabase databese = new FinanceiroDatabase();

                string script = string.Empty;

                if (radDia.Checked == true)
                {
                    script = "SELECT * FROM `venda` WHERE `dataVenda` = CURRENT_DATE()";
                }
                else if (radMes.Checked == true)
                {
                    FinanceiroDatabase database = new FinanceiroDatabase();
                    string data = database.ListarDataAtual("SELECT LEFT(NOW(), 8) AS agora");

                    string diaPrimeiro = data + "01";
                    string diaFinal = data + "31"; //chec para tratar o ultimo dia dos meses

                    script = "SELECT * FROM `venda` WHERE `dataVenda` BETWEEN '" + diaPrimeiro + "' AND '" + diaFinal + "'";
                }
                else if(radAno.Checked == true)
                {
                    FinanceiroDatabase database = new FinanceiroDatabase();
                    string data = database.ListarDataAtual("SELECT LEFT(NOW(), 5) AS agora");

                    string janeiro = data + "01-01";
                    string dezembro = data + "12-31";

                    script = "SELECT * FROM `venda` WHERE `dataVenda` BETWEEN '" + janeiro + "' AND '" + dezembro + "'";
                }
            }
            else
            {
                MessageBox.Show("Selecione o período.");
            }
        }
    }
}
