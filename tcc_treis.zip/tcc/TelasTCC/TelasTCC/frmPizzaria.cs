﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Pizzaria;

namespace TelasTCC
{
    public partial class frmPizzaria : Form
    {
        public frmPizzaria()
        {
            InitializeComponent();
            ListarBebidas();
            ListarSobremesas();
            cbSabor_dois.Enabled = false;
        }

        static int entregaSalao = 0;
        public void setEntregaSalao(int entreSalao) { entregaSalao = entreSalao; }

        private void btnEnviarBebidas_Click(object sender, EventArgs e)
        {
            PizzariaDTO dto = new PizzariaDTO();
            if (cbDose.Text != string.Empty) { dto.Produto = cbDose.Text; }
            if (cbLata.Text != string.Empty) { dto.Produto = cbLata.Text; }
            if (cbSuco.Text != string.Empty) { dto.Produto = cbSuco.Text; }
            
            if (txtBebidadaQtde.Text == string.Empty) { dto.QuantidadeProduto = "1"; }
            else { dto.QuantidadeProduto = txtBebidadaQtde.Text; }

            PizzariaDatabase database = new PizzariaDatabase();
            dto.IdProduto = database.ListarProduto(dto.Produto);

            dto.Preco = database.ListarValor(dto.Produto);

            dto.idPedido = database.ListarPedido();

            PizzariaBusiness business = new PizzariaBusiness();
            business.Salvar(dto);
            MessageBox.Show("Bebida cadastrada.");
        }

        private void btnEnviarSobremesa_Click(object sender, EventArgs e)
        {
            PizzariaDTO dto = new PizzariaDTO();
            if (cbSorvete.Text != string.Empty) { dto.Produto = cbSorvete.Text; }
            if (cbDoce.Text != string.Empty) { dto.Produto = cbDoce.Text; }
            
            if (txtSobremesaQtde.Text == string.Empty) { dto.QuantidadeProduto = "1"; }
            else { dto.QuantidadeProduto = txtSobremesaQtde.Text; }

            PizzariaDatabase database = new PizzariaDatabase();
            dto.IdProduto = database.ListarProduto(dto.Produto);

            dto.Preco = database.ListarValor(dto.Produto);

            dto.idPedido = database.ListarPedido();

            PizzariaBusiness business = new PizzariaBusiness();
            business.Salvar(dto);
            MessageBox.Show("Sobremesa cadastrada.");
        }

        private void ListarBebidas()
        {
            PizzariaBusiness business = new PizzariaBusiness();

            cbDose.DisplayMember = "nome";
            cbSuco.DisplayMember = "nome";
            cbLata.DisplayMember = "nome";

            int i = 0;
            while (i != 3)
            {
                if (i == 0) { DataTable lista = business.Listar("Dose"); cbDose.DataSource = lista; }
                i++;
                if (i == 1) { DataTable lista = business.Listar("Suco"); cbSuco.DataSource = lista; }
                i++;
                if (i == 2) { DataTable lista = business.Listar("Lata"); cbLata.DataSource = lista; }
                i = 3;
            }
        }

        private void ListarSobremesas()
        {
            PizzariaBusiness business = new PizzariaBusiness();

            cbSorvete.DisplayMember = "nome";
            cbDoce.DisplayMember = "nome";

            int i = 0;
            while (i != 2)
            {
                if (i == 0) { DataTable lista = business.Listar("Sorvete"); cbSorvete.DataSource = lista; }
                i++;
                if (i == 1) { DataTable lista = business.Listar("Doce"); cbDoce.DataSource = lista; }
                i = 2;
            }
        }

        private void btnEnviarPizza_Click(object sender, EventArgs e)
        {
            PizzariaDTO dto = new PizzariaDTO();
            if (cbSabor_um.Text != string.Empty) { dto.Produto = cbSabor_um.Text; }

            if (txtPizzaBrotoEsfirraQtde.Text == string.Empty) { dto.QuantidadeProduto = "1"; }
            else { dto.QuantidadeProduto = txtPizzaBrotoEsfirraQtde.Text; }

            PizzariaDatabase database = new PizzariaDatabase();
            dto.IdProduto = database.ListarProduto(dto.Produto);

            dto.Preco = database.ListarValor(dto.Produto);

            dto.idPedido = database.ListarPedido();

            PizzariaBusiness business = new PizzariaBusiness();
            business.Salvar(dto);
            MessageBox.Show("Refeição cadastrada.");
        }

        private void ListarPizzaBroto(string pizzaBroto)
        {
            PizzariaBusiness business = new PizzariaBusiness();

            cbSabor_um.DisplayMember = "nome";
            cbSabor_dois.DisplayMember = "nome";

            int i = 0;
            while (i != 2)
            {
                if (i == 0) { DataTable lista = business.Listar(pizzaBroto); cbSabor_um.DataSource = lista; }
                i++;
                if (i == 1) { DataTable lista = business.Listar(pizzaBroto); cbSabor_dois.DataSource = lista; }
                i = 2;
            }
        }

        private void btnEnviarTudo_Click(object sender, EventArgs e)
        {
            PizzariaDTO dto = new PizzariaDTO();
            PizzariaDatabase database = new PizzariaDatabase();

            dto.idPedido = database.ListarPedido();
            dto.ValorFinal = database.ListarValorFinal(dto.idPedido);
            dto.TipoPedido = entregaSalao.ToString();
            
            PizzariaBusiness business = new PizzariaBusiness();
            business.SalvarPedido(dto);

            MessageBox.Show("Venda Finalizada!");

            Form finalizar = new frmFinalizarCompra();
            finalizar.Show();
        }

        private void radPizza_CheckedChanged(object sender, EventArgs e)
        {
            ListarPizzaBroto("Pizza");
        }

        private void radEsfirra_CheckedChanged(object sender, EventArgs e)
        {
            ListarPizzaBroto("Esfirra");
        }

        private void radBroto_CheckedChanged(object sender, EventArgs e)
        {
            ListarPizzaBroto("Broto");
        }
        
        private void radMeia_CheckedChanged(object sender, EventArgs e)
        {
            if (radMeia.Checked == true)
            {
                cbSabor_dois.Enabled = true;
            }
            else
            {
                cbSabor_dois.Enabled = false;
            }
        }
    }
}
