﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Fornecedores;

namespace TelasTCC
{
    public partial class frmCadFornecedor : Form
    {
        public frmCadFornecedor()
        {
            InitializeComponent();
        }

        static int Id;
        public void SetId(int id) {
            Id = id;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (Id == 0)
            {
                Cadastrar();
            }
            else if (Id == 1)
            {
                Atualizar();
            }
        }

        public void Cadastrar()
        {
            FornecedoresDTO dto = new FornecedoresDTO();
            dto.Nome = txtNome.Text;
            dto.Fornecimento = txtFornecimento.Text;
            dto.TipoProduto = txtTipoProduto.Text;
            dto.Cnpj = txtCnpj.Text;
            dto.Telefone_um = txtTelefone.Text;
            dto.Telefone_dois = txtTelefoneDois.Text;

            if (dto.Telefone_um == string.Empty && dto.Telefone_dois == string.Empty)
            {
                MessageBox.Show("Telefone é obrigatório.");
                txtTelefone.Focus();
            }
            else
            {
                if (dto.Telefone_um == string.Empty && dto.Telefone_dois != string.Empty)
                {
                    dto.Telefone_um = dto.Telefone_dois;
                    dto.Telefone_dois = string.Empty;
                }
                FornecedoresBusiness business = new FornecedoresBusiness();
                business.Salvar(dto);
                MessageBox.Show("Fornecedor cadastrado.");
            }
        }

        public void Atualizar()
        {
            FornecedoresDTO dto = new FornecedoresDTO();
            dto.Nome = txtNome.Text;
            dto.Fornecimento = txtFornecimento.Text;
            dto.TipoProduto = txtTipoProduto.Text;
            dto.Cnpj = txtCnpj.Text;
            dto.Telefone_um = txtTelefone.Text;
            dto.Telefone_dois = txtTelefoneDois.Text;

            FornecedoresBusiness business = new FornecedoresBusiness();
            business.Atualizar(dto);
            MessageBox.Show("Fornecedor atualizado.");
        }
    }
}
