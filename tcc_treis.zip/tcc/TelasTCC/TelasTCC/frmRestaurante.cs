﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;  //apagar
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Restaurante;

namespace TelasTCC
{
    public partial class frmRestaurante : Form
    {
        public frmRestaurante()
        {
            InitializeComponent();
            ListarBebidas();
            ListarSobremesas();
        }

        static int entregaSalao = 0;
        public void setEntregaSalao(int entreSalao){entregaSalao = entreSalao;}


        private void btnEnviar_Click(object sender, EventArgs e)
        {
            txtPeso.Visible = true;
            cbRefeicao.Visible = false;
            txtPeso.Left = 373; 
        }

        private void btnEnviarBebida_Click(object sender, EventArgs e)
        {
            RestauranteDTO dto = new RestauranteDTO();
            if (cbDose.Text != string.Empty){dto.Produto = cbDose.Text;}
            if (cbLata.Text != string.Empty) { dto.Produto = cbLata.Text; }
            if (cbSuco.Text != string.Empty) { dto.Produto = cbSuco.Text; }
            dto.QuantidadeProduto = txtBebidadaQtde.Text;

            RestauranteDatabase database = new RestauranteDatabase();
            dto.IdProduto = database.ListarProduto(dto.Produto);

            dto.Preco = database.ListarValor(dto.Produto);

            dto.idPedido = database.ListarPedido();
            
            RestauranteBusiness business = new RestauranteBusiness();
            business.Salvar(dto);
            MessageBox.Show("Bebida cadastrada.");
        }
        private void ListarBebidas()
        {
            RestauranteBusiness business = new RestauranteBusiness();

            cbDose.DisplayMember = "nome";
            cbSuco.DisplayMember = "nome";
            cbLata.DisplayMember = "nome";
            
            int i = 0;
            while (i != 3)
            {
                if (i == 0) { DataTable lista = business.Listar("Dose"); cbDose.DataSource = lista; }
                i++;
                if (i == 1) { DataTable lista = business.Listar("Suco"); cbSuco.DataSource = lista; }
                i++;
                if (i == 2) { DataTable lista = business.Listar("Lata"); cbLata.DataSource = lista; }
                i = 3;
            }
        }

        private void ListarSobremesas()
        {
            RestauranteBusiness business = new RestauranteBusiness();

            cbSorvete.DisplayMember = "nome";
            cbDoce.DisplayMember = "nome";

            int i = 0;
            while (i != 2)
            {
                if (i == 0) { DataTable lista = business.Listar("Sorvete"); cbSorvete.DataSource = lista; }
                i++;
                if (i == 1) { DataTable lista = business.Listar("Doce"); cbDoce.DataSource = lista; }
                i = 2;
            }
        }

        private void btnEnviarSobremesa_Click(object sender, EventArgs e)
        {
            RestauranteDTO dto = new RestauranteDTO();
            if (cbSorvete.Text != string.Empty) { dto.Produto = cbSorvete.Text; }
            if (cbDoce.Text != string.Empty) { dto.Produto = cbDoce.Text; }
            dto.QuantidadeProduto = txtSobremesaQtde.Text;

            RestauranteDatabase database = new RestauranteDatabase();
            dto.IdProduto = database.ListarProduto(dto.Produto);

            dto.Preco = database.ListarValor(dto.Produto);

            dto.idPedido = database.ListarPedido();

            RestauranteBusiness business = new RestauranteBusiness();
            business.Salvar(dto);
            MessageBox.Show("Sobremesa cadastrada.");
        }

        private void btnEnviarTudo_Click(object sender, EventArgs e)
        {
            RestauranteDTO dto = new RestauranteDTO();
            RestauranteDatabase database = new RestauranteDatabase();

            dto.idPedido = database.ListarPedido();
            dto.ValorFinal = database.ListarValorFinal(dto.idPedido);
            dto.TipoPedido = entregaSalao.ToString();

            RestauranteBusiness business = new RestauranteBusiness();
            business.SalvarPedido(dto);

            MessageBox.Show("Venda Finalizada!");
        }

        private void radPeso_CheckedChanged(object sender, EventArgs e)
        {
            txtPeso.Visible = true;
            cbRefeicao.Visible = false;

            txtPeso.Focus();
        }

        private void radPratoFeito_CheckedChanged(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtPeso.Visible = false;
            cbRefeicao.Visible = true;
        }

        private void radFeijoada_CheckedChanged(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtPeso.Visible = false;
            cbRefeicao.Visible = true;

            // ---

            RestauranteBusiness business = new RestauranteBusiness();

            cbRefeicao.DisplayMember = "tamanho";
            
            DataTable lista = business.ListarRefeicao(); cbRefeicao.DataSource = lista;
             
        }

        private void btnEnviarRefeicao_Click(object sender, EventArgs e)
        {
            RestauranteDTO dto = new RestauranteDTO();
            if(radFeijoada.Checked == false && radPeso.Checked == false && radPratoFeito.Checked == false)
            {
                MessageBox.Show("Selecione o tipo de pedido de refeição");
            }
            else if(radFeijoada.Checked == false || radPeso.Checked == false || radPratoFeito.Checked == false)
            {
                if (radFeijoada.Checked == true){ dto.Produto = "Feijoada " +cbRefeicao.Text; }
                else if (radPeso.Checked == true) { dto.Produto = radPeso.Text; }
                else if (radPratoFeito.Checked == true) { dto.Produto = radPratoFeito.Text + " " + cbRefeicao.Text; }

                dto.QuantidadeProduto = "1";

                RestauranteDatabase database = new RestauranteDatabase();
                dto.IdProduto = database.ListarProduto(dto.Produto);

                if (txtPeso.Text == string.Empty)
                {
                    dto.Preco = database.ListarValor(dto.Produto);
                }
                else if(txtPeso.Text != string.Empty) // PARTE DO PRATO FEITO
                {
                    dto.Preco = "" + (float.Parse(txtPeso.Text) * 2);
                }
                
                dto.idPedido = database.ListarPedido();
                
                RestauranteBusiness business = new RestauranteBusiness();
                business.Salvar(dto);
                MessageBox.Show("Refeição cadastrada.");
            }
        }
    }
}
