﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Funcionario;

namespace TelasTCC
{
    public partial class frmModFuncionarios : Form
    {
        public frmModFuncionarios()
        {
            InitializeComponent();

            FuncionarioBusiness business = new FuncionarioBusiness();
            List<FuncionarioDTO> lista = business.Listar();

            dgvFuncionario.AutoGenerateColumns = false;
            dgvFuncionario.DataSource = lista;
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            if (gbDados.Height == 115) { gbDados.Height = 85; this.Height = 379; }
            else { gbDados.Height = 115; this.Height = 404; }

            string id = this.dgvFuncionario.CurrentRow.Cells[0].Value.ToString();
            
            FuncionarioDatabase database = new FuncionarioDatabase();

            int val = 0;
            string msg = string.Empty;

            if(cbDados.Text == "CPF"){val = 0;msg = "CPF: "; }
            else if (cbDados.Text == "Data de nascimento") { val = 1; msg = "Data de nascimento: "; }
            else if (cbDados.Text == "Endereço") { val = 2; msg = "Endereço: "; }
            //else if (cbDados.Text == "RG") { val = 3; msg = "RG: "; }

            string campo = database.ListarFuncionario(val, id);
            lblInformacoes.Text = msg + campo;
        }
    }
}
