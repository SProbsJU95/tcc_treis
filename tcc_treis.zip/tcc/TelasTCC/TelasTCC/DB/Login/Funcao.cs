﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Login
{
    class Funcao
    {
        static string funcionarioFuncao;

        public void SetFuncao(string funcao)
        {
            funcionarioFuncao = funcao;
        }

        public string GetFuncao()
        {
            return funcionarioFuncao;
        }
    }
}
