﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.Endereco
{
    class EnderecoDatabase
    {
        public int Salvar(EnderecoDTO dto)
        {
            string script = @"insert into endereco (Bairro, CEP, complemento, numero, Rua) values(@Bairro, @CEP, @complemento, @numero, @Rua)";

            List<MySqlParameter> parms = new List<MySqlParameter>();
            parms.Add(new MySqlParameter("Bairro", dto.Bairro));
            parms.Add(new MySqlParameter("CEP", dto.Cep));
            parms.Add(new MySqlParameter("complemento", dto.Complemento));
            parms.Add(new MySqlParameter("numero", dto.Numero));
            parms.Add(new MySqlParameter("Rua", dto.Rua));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }


        public string AtribuirEndereco()
        {
            //string script = "SELECT MAX(idEndereco) FROM endereco";
            string script = "SELECT * FROM endereco";//como resouver um erro na cagada com Robson 2019
            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<EnderecoDTO> listaSenha = new List<EnderecoDTO>();

            string endereco = "";

            while (reader.Read())
            {
                EnderecoDTO dto = new EnderecoDTO();
                dto.IdEndereco = reader.GetString("idEndereco");

                endereco = dto.IdEndereco;
            }
            reader.Close();
            
            return endereco;
        }
    }
}
